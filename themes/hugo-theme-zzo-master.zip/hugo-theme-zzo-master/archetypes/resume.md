---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
description: 
type: resume
enableToc: false
header:
  image: 
    src: 
    height: 
    alt: 
  infos:
    name: 
    email: 
    phone: 
    website: 
    addr: 
items:
  - title: 
    sections:
      - title: 
        subtitle: 
        startDate: 
        endDateText: 
        endDate: 
        contents: | 
        
  - title: 
    sections:
      - title: 
        subtitle: 
        startDate: 
        endDateText: 
        endDate: 
        contents: | 
---