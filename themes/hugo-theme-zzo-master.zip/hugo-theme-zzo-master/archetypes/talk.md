---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
publishDate: {{ .Date }}
description:
tags:
-
series:
-
categories:
-
titleWrap: wrap # wrap, noWrap
---