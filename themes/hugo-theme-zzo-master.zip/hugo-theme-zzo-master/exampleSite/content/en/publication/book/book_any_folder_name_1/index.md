---
authors: ['zzossig']
publisher: "Self-Published"
abstract: "Donec vel ipsum vulputate, dapibus magna quis, auctor mauris. Aliquam ut dapibus risus. Duis sit amet magna posuere, interdum metus sed, maximus tortor. Maecenas tempus ut magna nec facilisis. Pellentesque vel ultrices nunc, eget ultrices mauris. Ut eget ligula quis purus porta rhoncus eget at eros. In id felis ullamcorper, vehicula ante sed, cursus magna. Curabitur libero nibh, posuere in urna in, viverra pulvinar lectus. Pellentesque rutrum tempus elit at hendrerit. Sed enim est, bibendum in augue iaculis, viverra venenatis sapien. Nullam sagittis augue maximus mi interdum maximus. Praesent a cursus massa."
shorttitle: "Donec vel ipsum vulputate"
isbn: "978-1-311-04245-3"
copyright: "All rights reserved"
title: "Donec vel ipsum vulputate, dapibus magna quis"
ENTRYTYPE: "book"
enableToc: False
enableWhoami: True
pinned: true
publishDate: "2017-06-01"
---