---
authors: ['zzossig', 'teemo']
publication: "abc"
abstract: "Duis vulputate odio vitae consectetur lacinia. Vivamus tellus nisi, hendrerit eget tortor eget, rutrum lobortis tellus. Donec convallis scelerisque egestas. Vestibulum ex urna, commodo at interdum vitae, malesuada id arcu. Praesent et enim libero. Proin et felis nisi. Duis imperdiet placerat dapibus."
links:
 - name: url
   link: https://google.com
shorttitle: "Book Review"
copyright: "All rights reserved"
title: "Book Review: Duis vulputate"
ENTRYTYPE: "misc"
enableToc: False
enableWhoami: True
pinned: true
publishDate: "2016-11-01"
---